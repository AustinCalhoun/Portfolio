﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Program4
{
    class Program
    {
        static void Main(string[] args)
        {
            //hardcoded objects for use in array of which is used for display
            Product type1 = new Product("Pepsi", "Gatorade", 3678636, "Beverage", 1.29, 6);
            Product type2 = new Product("Dole", "Apple Sauce", 502513, "Fruit", 3.25, 8);
            Product type3 = new Product("Yachty's", "Pizza", 744749, "Food", 7.50, 3);
            Product type4 = new Product("Sanbritos", "Doritos", 544595, "Snack", 3.99, 6);
            Product type5 = new Product("Pillsbury", "Biscuits", 708535, "Food", 3.49, 3);

            // Declared arrays to establish list of products and corresponding data
            Product[] types = { type1, type2, type3, type4, type5 };


            Console.WriteLine("\n--------------------\nList of Our Products\n--------------------\n");
            Print(types);
            //Updated inventory and use of the InStock method called = true displays in stock
            type1.SupplierName = "CocaCola";
            type1.ProductPrice = 1.50;
            type1.InStock();

            type2.ProductName = "Tony's Pizza";
            type2.ProductID = 744797;
            type2.ProductType = "Frozen Product";
            type2.AisleLocation = 4;
            type2.InStock();

            type3.ProductName = "Pizza Rolls";
            type3.ProductPrice = 3.99;
            type3.AisleLocation = 6;

            type4.ProductID = 515022;
            type4.ProductName = "Cheetos";
            type4.InStock();

            type5.ProductID = 355357;
            type5.ProductPrice = 4.99;
            type5.ProductName = "Jimmy Dean's";
            

            Console.WriteLine("\n-----------------\nUpdated Inventory\n-----------------\n");
            Print(types);
        }
        //Print method that indexes product array and displays hardcoded objects
        static void Print(Product[] types)
        {
            for (int index = 0; index < types.Length; index++)
            {
                Console.WriteLine(types[index].ToString());
            }
        }
    }
}