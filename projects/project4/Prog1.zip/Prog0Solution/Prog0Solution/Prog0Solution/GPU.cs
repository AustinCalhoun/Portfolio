﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0Solution
{
    internal class GPU
    {
        private string manufacturer;
        private string model;
        private int vRam;
        private int powerDraw;

        public GPU(string manufacturer, string model, int vRam, int powerDraw)
        {
            Manufacturer = manufacturer;
            Model = model;
            VRAM = vRam;
            PowerDraw = powerDraw;
        }

        public string Manufacturer
        {
            get
            {
                return manufacturer;
            }
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    manufacturer = value.Trim();
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }
            }
        }


        public string Model
        {
            get
            {
                return model;
            }
            set
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    model = value.Trim();
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }
            }
        }
        public int VRAM
        {
            get
            {
                return vRam;
            }
            set
            {
                if (value >= 0 && value <= 50000)
                {
                    vRam = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }
            }
        }

        public int PowerDraw
        {
            get
            {
                return powerDraw;
            }
            set
            {
                if (value >= 0 && value <= 2000)
                {
                    powerDraw = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }
            }
        }

        public override string ToString()
        {
            return $"{Manufacturer} {Model}\nClock Speed: {VRAM} MHz\nSocket: {PowerDraw} Watts";
        }
    }
}
