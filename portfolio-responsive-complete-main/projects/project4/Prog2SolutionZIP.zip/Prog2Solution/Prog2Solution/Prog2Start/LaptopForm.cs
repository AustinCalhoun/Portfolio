﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog3Start
{
    [Serializable]
    public partial class LaptopForm : Form
    {
        public LaptopForm()
        {
            InitializeComponent();
        }

        private void createButton_Click(object sender, EventArgs e)
        {
            //first, validate all 
            
            if (this.ValidateChildren())
            {
                try //this try will catch if data is invalid, since we only checked format. 
                {
                    
                    //first, create cpu
                    CPU cpu = new CPU(cpuMText.Text, cpuModTextBox.Text, int.Parse(cpuClockTextBox.Text), cpuSocTextBox.Text, int.Parse(cpuPDTextBox.Text));

                    //now, create laptop
                    Laptop someLaptop = new Laptop(manuTextBox.Text, modTextBox.Text, cpu, int.Parse(fixTDPTextBox.Text));
                    CreatedLaptop = someLaptop;

                    Hide();

                    DialogResult = DialogResult.OK;

                }
                catch
                {
                    MessageBox.Show("Cannot create Laptop", "Creation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        internal Laptop CreatedLaptop
        {
            get; set;
        }

        private void text_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(((TextBox)sender).Text))
            {
                laptopErrorProv.SetError((TextBox)sender, "Invalid Text Entered");
                e.Cancel = true;
            }
        }

        private void text_Validated(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(((TextBox)sender).Text))
            {
                laptopErrorProv.SetError((TextBox)sender, "");
            }
        }

        private void int_Validating(object sender, CancelEventArgs e)
        {
            if (!int.TryParse(((TextBox)sender).Text, out int result) || result < 0)
            {
                laptopErrorProv.SetError((TextBox)sender, "Invalid Integer Entered");
                e.Cancel = true;
            }
        }

        private void int_Validated(object sender, EventArgs e)
        {
            if (int.TryParse(((TextBox)sender).Text, out int result) && result >= 0)
            {
                laptopErrorProv.SetError((TextBox)sender, "");
            }
        }
    }
}
