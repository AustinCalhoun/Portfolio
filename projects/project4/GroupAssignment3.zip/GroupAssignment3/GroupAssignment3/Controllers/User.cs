﻿namespace GroupAssignment3.Controllers
{
    public class User
    {
        public string DisplayName { get; set; }
        public DateTime RegisterDate { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Rank { get; set; }
        public int ELO { get; set; }
    }
}
