﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0Solution
{
    class AllInOne : Desktop
    {
        private int screenXSize;
        private int screenYSize;
        public AllInOne(string manufacturer, CPU cpu, GPU gpu, MotherBoard motherBoard, int fanCount, int screenXSize, int screenYSize)//constructor
            : base(manufacturer, cpu, gpu, motherBoard, fanCount)
        {
            ScreenXSize = screenXSize;
            ScreenYSize = screenYSize;
        }
        public int ScreenXSize
        {
            get
            {
                return screenXSize;
            }
            set
            {
                if (value >= 0 && value <= 10000)
                {
                    screenXSize = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }
            }
        }
        public int ScreenYSize
        {
            get
            {
                return screenYSize;
            }
            set
            {
                if (value >= 0 && value <= 10000)
                {
                    screenYSize = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }
            }
        }
        public double AspectRatio
        {
            get { return ScreenXSize / ScreenYSize; }
        }
        public override double CalcTDP() //=> CPU.PowerDraw + GPU.PowerDraw + MotherBoard.PowerDraw
        {
            return CPU.PowerDraw + GPU.PowerDraw + MotherBoard.PowerDraw + (0.000042 * ScreenXSize * ScreenYSize);
        }
        public override string ToString()
        {
            return $"Manufacturer: {Manufacturer} \n" +
                $"CPU Details: {CPU}\n" +
                $"GPU Details: {GPU}\n" +
                $"MotherBoard Details: {MotherBoard}\n" +
                $"Fan Count: {FanCount}\n" +
                $"Aspect Ratio: {AspectRatio}";
        }
    }
}
