﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog3Start
{
    public partial class AllInOneForm : Form
    {
        public AllInOneForm()
        {
            InitializeComponent();
        }

        private void createButton_Click(object sender, EventArgs e)
        {
            //first, validate all 
            
            if (this.ValidateChildren())
            {
                
                try //this try will catch if data is invalid, since up to now we only check format. 
                {
                    //first, create cpu
                    CPU cpu = new CPU(cpuMText.Text, cpuModTextBox.Text, int.Parse(cpuClockTextBox.Text), cpuSocTextBox.Text, int.Parse(cpuPDTextBox.Text));
                    //then, GPU
                    GPU gpu = new GPU(gpuManTextBox.Text, gpuModTextBox.Text, int.Parse(gpuVRAMTextBox.Text), int.Parse(gpuPDTextBox.Text));
                    //Then, motherboard
                    Motherboard mb = new Motherboard(mbManTextBox.Text, mbModTextBox.Text, mbSocketTextBox.Text, int.Parse(mbPDTextBox.Text));

                    //now, create AIO
                    AllInOne someAllInOne = new AllInOne(manuTextBox.Text, cpu, gpu, mb, int.Parse(fansTextBox.Text), int.Parse(xSizeTextBox.Text), int.Parse(ySizeTextBox.Text));
                    CreatedAllInOne = someAllInOne;

                    Hide();
                    DialogResult = DialogResult.OK;
                }
                catch
                {
                    MessageBox.Show("Cannot create All In One", "Creation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                
            }
            
        }

        internal AllInOne CreatedAllInOne
        {
            get; set;
        }

        private void text_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(((TextBox)sender).Text))
            {
                aioErrorProv.SetError((TextBox)sender, "Invalid Text Entered");
                e.Cancel = true;
            }
        }

        private void text_Validated(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(((TextBox)sender).Text))
            {
                aioErrorProv.SetError((TextBox)sender, "");
            }
        }

        private void int_Validating(object sender, CancelEventArgs e)
        {
            if (!int.TryParse(((TextBox)sender).Text, out int result) || result < 0)
            {
                aioErrorProv.SetError((TextBox)sender, "Invalid Integer Entered");
                e.Cancel = true;
            }
        }

        private void int_Validated(object sender, EventArgs e)
        {
            if (int.TryParse(((TextBox)sender).Text, out int result) && result >= 0)
            {
                aioErrorProv.SetError((TextBox)sender, "");
            }
        }
    }
}
