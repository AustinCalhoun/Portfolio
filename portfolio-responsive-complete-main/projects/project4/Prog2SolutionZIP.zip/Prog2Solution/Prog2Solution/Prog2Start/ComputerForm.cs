﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.Xml;
using System.Xml.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Linq.Expressions;

namespace Prog3Start
{
    public partial class computerViewForm : Form
    {
        public computerViewForm()
        {
            InitializeComponent();
        }

        List<Computer> computers = new List<Computer>();

        private void detailsButton_Click(object sender, EventArgs e)
        {
            if (compListView.SelectedIndices.Count >= 1)
            {
                int selectedIndex = compListView.SelectedIndices[0];

                MessageBox.Show(computers[selectedIndex].ToString());
            }
            else
            {
                MessageBox.Show("No Item Selected", "No Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Grading ID: 1850661, CIS 200");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void laptopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LaptopForm laptopCreate = new LaptopForm();
            laptopCreate.ShowDialog();
            if (laptopCreate.DialogResult == DialogResult.OK)
            {
                Laptop created = laptopCreate.CreatedLaptop;

                string[] listItem = { created.Manufacturer, created.CalcTDP().ToString(), "Laptop" };

                ListViewItem toAdd = new ListViewItem(listItem);

                compListView.Items.Add(toAdd);
                computers.Add(created);
            }
            laptopCreate.Dispose();

        }

        private void allInOneToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AllInOneForm aioCreate = new AllInOneForm();
            aioCreate.ShowDialog();
            if (aioCreate.DialogResult == DialogResult.OK)
            {
                AllInOne created = aioCreate.CreatedAllInOne;

                string[] listItem = { created.Manufacturer, created.CalcTDP().ToString(), "All In One" };

                ListViewItem toAdd = new ListViewItem(listItem);

                compListView.Items.Add(toAdd);
                computers.Add(created);
            }
            aioCreate.Dispose();
        }

        private void towerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TowerForm towerCreate = new TowerForm();
            towerCreate.ShowDialog();
            if (towerCreate.DialogResult == DialogResult.OK)
            {
                Tower created = towerCreate.CreatedTower;
                string[] listItem = { created.Manufacturer, created.CalcTDP().ToString(), "Tower" };

                ListViewItem toAdd = new ListViewItem(listItem);

                compListView.Items.Add(toAdd);
                computers.Add(created);
            }
            towerCreate.Dispose();
            
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog pathSelection = new SaveFileDialog())//opens save modal for user
            {
                pathSelection.InitialDirectory = "c:\\";//sets initial directory to c
                pathSelection.Title = "Computer List Saver";// name of modal savedialog box
                pathSelection.FileName = "BIN_Filename";// sets defualt file name
                pathSelection.DefaultExt = ".bin";// default extension
                pathSelection.Filter = "BIN-File | *.bin";// filter for binary type files

                DialogResult outputType = pathSelection.ShowDialog();// output type = user selected file path with constraints

                if (outputType == DialogResult.OK)// if user clicks ok
                {
                    string filePath = pathSelection.FileName;//variable filepath assigned to userselction
                }
                using (FileStream binaryStreamer = new FileStream(pathSelection.FileName, FileMode.Create))//creates object binaryStreamer as filestream input
                {
                    BinaryFormatter empBinFormatter = new BinaryFormatter();//creates object for serialization
                    empBinFormatter.Serialize(binaryStreamer, computers);//takes assigned object of binaryformatter and serializes it
                }
            }
        }
        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Would you like to delete current listview items?", "Clear Listview", MessageBoxButtons.OKCancel);//ask user to clear list of objects

            if (result == DialogResult.OK)//if user clicks ok
            {
                compListView.Items.Clear();//clears list of computers
            }
            if (result == DialogResult.Cancel)//if user clicks cancel the modal box closes
            {
                //do nothing
            }
            try 
            {
                using (OpenFileDialog pathSelection = new OpenFileDialog())//opens modal box for loading event
                {
                    pathSelection.InitialDirectory = "c:\\";//sets initial directory to c
                    pathSelection.Title = "Computer List Selector";// name of modal savedialog box
                    pathSelection.FileName = "BIN_Filename";// sets defualt file name
                    pathSelection.Filter = "BIN-File | *.bin";// filter for binary type files
                    pathSelection.FilterIndex = 1;//index for drop down menu

                    DialogResult inputType = pathSelection.ShowDialog();// input type = user selected file path with constraints

                    if (inputType == DialogResult.OK)// if user clicks ok
                    {
                        using (FileStream binaryLoadStream = new FileStream(pathSelection.FileName, FileMode.Open))// writes to the filestream as object binaryLoadStream
                        {
                            BinaryFormatter empBinDeserialize = new BinaryFormatter();
                            computers = (List<Computer>)empBinDeserialize.Deserialize(binaryLoadStream);
                        }
                    }
                }
            }
            catch (FileLoadException Ex)
            {
                // let the user know that the file is invalid
                MessageBox.Show("File not found: " + Ex.Message);
            }
            catch (Exception Ex)
            {
                // let the user know that there was an error with input
                MessageBox.Show("Input Error: " + Ex.Message);
            }

            foreach (Computer comp in computers)//assigns the fields to the listview
            {
                try
                {
                    string[] outputField = new string[3];

                    outputField[0] = comp.Manufacturer;
                    outputField[1] = comp.CalcTDP().ToString();
                    outputField[2] = comp.GetType().Name.ToString();

                    ListViewItem outputItem = new ListViewItem(outputField);
                    compListView.Items.Add(outputItem);
                }
                catch (NotSupportedException Ex)
                {
                    // let the user know that the input data was not correct 
                    MessageBox.Show("File type not supported" + Ex.Message);
                }
            }
        }
    }
}
