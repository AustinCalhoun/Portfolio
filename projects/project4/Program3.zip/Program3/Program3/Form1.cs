﻿/*
Grading ID: F2207
Program: 3
Due Date: 11/15/2022
Course Section: CIS-199-50-4228
This code executes program 3
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program3
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string[] loanTypeSearch = { "Home", "Auto", "Unsecured" };//declared arrays for use with form
        double[] loanTypeRate = { 1, 1.3, 2 };

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (string loan in loanTypeSearch)
            {
                loanCombox.Items.Add(loan);//allows contents from loanTypeSearch to be loaded to the combo box
            }
        }
        private void CalcButton_Click(object sender, EventArgs e)
        {

            int[] creditRange = { 300, 580, 670, 740, 800 };//declared parallel array for credit score
            string[] creditRating = { "Poor", "Fair", "Good", " Very Good", "Excellent" };
            double[] loanInterest = { .08014, .07373, .07062, .06149, .059 };


            double[] loanAmountSearch = { 1, 500, 2000, 10000, 100000 };//declared parallel array for range search for user input loan amount
            double[] downPayment = { 0, 0.10, 0.15, 0.10, 0.05 };

            bool creditFound = false;//declared bool type to test the range search until true
            bool amountFound = false;
            
            int creditScore;//variable declared to gather user input credit score
            double loanAmount;//variable declared to gather user input amount borrowed
            double downPaymentAmount;//used for final calculations
            double total = 0;//used for final calculations
            double interestCost = 0;//used to calculate loan interest*base rate
            
            const double DOWN_PAY_MIN = 1;//declared to test lows and highs to insure correct user input data down payment
            const double DOWN_PAY_MAX = 500000;
            const int CREDIT_MIN = 300;//declared to test lows and highs to insure correct user input data credit score
            const int CREDIT_MAX = 850;

            if (int.TryParse(creditScoreTxt.Text, out creditScore) && creditScore >= CREDIT_MIN && creditScore <= CREDIT_MAX)//test condition to insure correct range
            {
                if (double.TryParse(loanAmountTxt.Text, out loanAmount) && loanAmount >= DOWN_PAY_MIN && loanAmount <= DOWN_PAY_MAX)
                {
                    if (loanCombox.SelectedIndex >= 0)//test condition to insure user selection
                    {
                        double interest = 0;//used to calculate interest
                        int creditIndex = creditRange.Length - 1;//used to test array
                        while (creditIndex >= 0 && !creditFound)//and condition to test and allow stoppage once boolean = true
                        {
                            if (creditScore >= creditRange[creditIndex])//once correct range is found the index's value is stored until later usage
                                creditFound = true;

                            else
                                --creditIndex;//negates if bool = false
                        }

                        int amountIndex = loanAmountSearch.Length - 1;//this uses the same contruction as the loop above
                        while (amountIndex >= 0 && !amountFound)
                        {
                            if (loanAmount >= loanAmountSearch[amountIndex])
                                amountFound = true;

                            else
                                --amountIndex;
                        }
                        if (creditFound)//once credit/amount booleans variables = true the incremented values(index) are ready for use. the loops use the information for purpose of calculation
                        {
                            creditRatingOut.Text = creditRating[creditIndex];//for dislay of array string type to textbox
                            interest = loanInterest[creditIndex];//sets loan interest to credit index value and stores into variable interest
                            interestCost = interest * loanTypeRate[loanCombox.SelectedIndex];//uses data from user selected array for calculation with interest. stored in interestCost
                        }
                        if (amountFound)// if amount = true, executes calculations
                        {
                            double downPaymentPercent = downPayment[amountIndex];//declare variable downPaymentPercent of which the corresponding indexed value of downPayment is assigned
                            downPaymentAmount = loanAmount * downPaymentPercent;//user input * indexed downpayment percent
                            total = downPaymentAmount;//total is used to calculate the final output
                        }
                            downPaymentOut.Text = total.ToString("C");//outputs data to labels
                            loanInterestOut.Text = interestCost.ToString("P");
                    }
                    else
                    {
                        MessageBox.Show("Select a loan type!");//error boxes
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Loan Amount Entered!");
                }
            }
            else
            {
                MessageBox.Show("Invalid Credit Score Entered!");
            }
        }
    }
}
