﻿
namespace Program3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.loanCombox = new System.Windows.Forms.ComboBox();
            this.creditScoreTxt = new System.Windows.Forms.TextBox();
            this.loanAmountTxt = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.CalcButton = new System.Windows.Forms.Button();
            this.loanInterestOut = new System.Windows.Forms.Label();
            this.creditRatingOut = new System.Windows.Forms.Label();
            this.downPaymentOut = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Loan Type";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Credit Score";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(61, 166);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Loan Amount";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(63, 264);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Loan Interest";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(63, 296);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Credit Rating";
            // 
            // loanCombox
            // 
            this.loanCombox.FormattingEnabled = true;
            this.loanCombox.Location = new System.Drawing.Point(233, 89);
            this.loanCombox.Name = "loanCombox";
            this.loanCombox.Size = new System.Drawing.Size(121, 21);
            this.loanCombox.TabIndex = 5;
            // 
            // creditScoreTxt
            // 
            this.creditScoreTxt.Location = new System.Drawing.Point(233, 123);
            this.creditScoreTxt.Name = "creditScoreTxt";
            this.creditScoreTxt.Size = new System.Drawing.Size(100, 20);
            this.creditScoreTxt.TabIndex = 6;
            // 
            // loanAmountTxt
            // 
            this.loanAmountTxt.Location = new System.Drawing.Point(233, 159);
            this.loanAmountTxt.Name = "loanAmountTxt";
            this.loanAmountTxt.Size = new System.Drawing.Size(100, 20);
            this.loanAmountTxt.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(61, 328);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Down Payment";
            // 
            // CalcButton
            // 
            this.CalcButton.Location = new System.Drawing.Point(233, 201);
            this.CalcButton.Name = "CalcButton";
            this.CalcButton.Size = new System.Drawing.Size(87, 30);
            this.CalcButton.TabIndex = 9;
            this.CalcButton.Text = "Calculate";
            this.CalcButton.UseVisualStyleBackColor = true;
            this.CalcButton.Click += new System.EventHandler(this.CalcButton_Click);
            // 
            // loanInterestOut
            // 
            this.loanInterestOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.loanInterestOut.Location = new System.Drawing.Point(233, 257);
            this.loanInterestOut.Name = "loanInterestOut";
            this.loanInterestOut.Size = new System.Drawing.Size(107, 20);
            this.loanInterestOut.TabIndex = 10;
            // 
            // creditRatingOut
            // 
            this.creditRatingOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.creditRatingOut.Location = new System.Drawing.Point(233, 289);
            this.creditRatingOut.Name = "creditRatingOut";
            this.creditRatingOut.Size = new System.Drawing.Size(107, 20);
            this.creditRatingOut.TabIndex = 11;
            // 
            // downPaymentOut
            // 
            this.downPaymentOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.downPaymentOut.Location = new System.Drawing.Point(233, 321);
            this.downPaymentOut.Name = "downPaymentOut";
            this.downPaymentOut.Size = new System.Drawing.Size(107, 20);
            this.downPaymentOut.TabIndex = 12;
            // 
            // Form1
            // 
            this.AcceptButton = this.CalcButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(414, 410);
            this.Controls.Add(this.downPaymentOut);
            this.Controls.Add(this.creditRatingOut);
            this.Controls.Add(this.loanInterestOut);
            this.Controls.Add(this.CalcButton);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.loanAmountTxt);
            this.Controls.Add(this.creditScoreTxt);
            this.Controls.Add(this.loanCombox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Loan Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox loanCombox;
        private System.Windows.Forms.TextBox creditScoreTxt;
        private System.Windows.Forms.TextBox loanAmountTxt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button CalcButton;
        private System.Windows.Forms.Label loanInterestOut;
        private System.Windows.Forms.Label creditRatingOut;
        private System.Windows.Forms.Label downPaymentOut;
    }
}

