﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml;
using System.Xml.Serialization;

namespace GroupAssignment3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        [HttpGet(Name = "GetUser")]
        public IActionResult GetUser(string displayName)
        {
            string filename = "TestFile.xml";
            XmlDocument xmlDoc = new XmlDocument();
            XmlSerializer serializer = new XmlSerializer(typeof(List<User>));

            xmlDoc.Load(filename);
            string xmlString = xmlDoc.OuterXml;

            List<User> retrieved = new List<User>();
            User requestedUser = new User();

            using (StringReader sr = new StringReader(xmlString))
            {
                using (XmlReader reader = XmlReader.Create(sr))
                {
                    retrieved = (List<User>)serializer.Deserialize(reader);
                }
            }

            bool found = false;
            for (int i = 0; i < retrieved.Count; i++)
            {
                if (retrieved[i].DisplayName == displayName)
                {
                    found = true;
                    requestedUser = retrieved[i];
                }
            }

            if (found == true)
            {
                return Ok(requestedUser);
            }
            else
            {
                return NotFound($"Student {displayName} Doesn't Exist in Database");
            }
        }

        [HttpPut("{displayName}", Name = "PutUser")]
        public IActionResult PutUser(string displayName, [FromBody] User userData)
        {
            // Preliminary validation: Ensure userData and displayName are provided.
            if (userData == null || string.IsNullOrWhiteSpace(displayName))
            {
                return BadRequest("Invalid User Input.");
            }
            // Age Verification
            int age = DateTime.Now.Year - userData.DateOfBirth.Year;
            if (userData.DateOfBirth > DateTime.Now.AddYears(-age)) age--;
            if (age < 12)
            {
                return BadRequest("User is too young. Users must be at least 12 years old.");
            }
            // Validate incoming userData
            List<string> missingFields = new List<string>();
            if (string.IsNullOrWhiteSpace(userData.DisplayName))
            {
                missingFields.Add(nameof(userData.DisplayName));
            }
            if (userData.DateOfBirth == default)
            {
                missingFields.Add(nameof(userData.DateOfBirth));
            }
            if (missingFields.Count > 0)
            {
                return BadRequest($"Missing or invalid data for the following fields: {string.Join(", ", missingFields)}.");
            }

            // Load the existing users from XML.
            string filename = "TestFile.xml";
            List<User> usersList;
            XmlSerializer serializer = new XmlSerializer(typeof(List<User>));

            try
            {
                using (FileStream fs = new FileStream(filename, FileMode.Open))
                {
                    usersList = (List<User>)serializer.Deserialize(fs);
                }
            }
            catch (FileNotFoundException)
            {
                return NotFound("Data file not found.");
            }

            // Find the user with the matching DisplayName.
            var userIndex = usersList.FindIndex(u => u.DisplayName.Equals(displayName, StringComparison.OrdinalIgnoreCase));
            if (userIndex == -1)
            {
                // User not found
                return NotFound($"User with DisplayName '{displayName}' not found.");
            }

            usersList[userIndex] = userData;

            // Save the updated list back to the XML file
            try
            {
                using (FileStream fs = new FileStream(filename, FileMode.Create))
                {
                    serializer.Serialize(fs, usersList);
                }
            }
            catch (Exception ex) // Throws exception
            {
                // Log the exception, etc.
                return StatusCode(500, "An error occurred while saving the data.");
            }

            return Ok(userData);
        }



        [HttpPost(Name = "PostUser")]
        public IActionResult PostUser([FromBody] User userData)
        {
            List<User> List = new List<User>();

            // Age Verification
            int age = DateTime.Now.Year - userData.DateOfBirth.Year;
            if (userData.DateOfBirth > DateTime.Now.AddYears(-age)) age--;
            if (age < 12)
            {
                return BadRequest("User is too young. Users must be at least 12 years old.");
            }
            // Validate incoming userData
            List<string> missingFields = new List<string>();
            if (string.IsNullOrWhiteSpace(userData.DisplayName))
            {
                missingFields.Add(nameof(userData.DisplayName));
            }
            if (userData.DateOfBirth == default)
            {
                missingFields.Add(nameof(userData.DateOfBirth));
            }
            if (missingFields.Count > 0)
            {
                return BadRequest($"Missing or invalid data for the following fields: {string.Join(", ", missingFields)}.");
            }


            string filename = "TestFile.xml";
            XmlDocument xmlDoc = new XmlDocument();
            XmlSerializer serializer = new XmlSerializer(typeof(List<User>));

            xmlDoc.Load(filename);
            string xmlString = xmlDoc.OuterXml;


            using (StringReader sr = new StringReader(xmlString))
            {
                using (XmlReader reader = new XmlTextReader(sr))
                {
                    List = (List<User>)serializer.Deserialize(reader);
                }
            }
            if (userData != null)
            {
                List.Add(userData);

                using (MemoryStream ms = new MemoryStream())
                {
                    serializer.Serialize(ms, List);
                    ms.Position = 0;
                    xmlDoc.Load(ms);
                    xmlDoc.Save(filename);
                    ms.Close();


                }
                return Ok(userData);
            }
            else
            {
                return NoContent();
            }

        }

        [HttpDelete(Name = "DeletedUser")]
        public IActionResult DeleteUser(string DisplayName)
        {
            List<User> List = new List<User>();

            string filename = "TestFile.xml";
            XmlDocument xmlDoc = new XmlDocument();
            XmlSerializer serializer = new XmlSerializer(typeof(List<User>));

            xmlDoc.Load(filename);
            string xmlString = xmlDoc.OuterXml;


            using (StringReader sr = new StringReader(xmlString))
            {
                using (XmlReader reader = new XmlTextReader(sr))
                {
                    List = (List<User>)serializer.Deserialize(reader);
                }
            }

            bool found = false;
            int foundIndex = -1;
            User pop = new User();
            for (int i = 0; i < List.Count; i++)
            {
                if (List[i].DisplayName == DisplayName)
                {
                    found = true;
                    foundIndex = i;
                    pop = List[i];
                }
            }

            if (found == true)
            {
                List.RemoveAt(foundIndex);
                using (MemoryStream ms = new MemoryStream())
                {
                    serializer.Serialize(ms, List);
                    ms.Position = 0;
                    xmlDoc.Load(ms);
                    xmlDoc.Save(filename);
                    ms.Close();


                }
                //return Ok($"Student {DisplayName} was deleted");
                return Ok(pop);
            }
            else
            {
                return NotFound($"The Student {DisplayName} Does Not Exist");
            }

        }


    }
    //public class DataHelper
    //{
    //    public static void WriteTestData()
    //    {
    //        User student1 = new User();
    //        student1.DisplayName = "Castigador";
    //        student1.RegisterDate = new DateTime(2019, 2, 12);
    //        student1.DateOfBirth = new DateTime(2000, 1, 1);
    //        student1.Rank = "Diamond";
    //        student1.ELO = 1550;
    //        string filename = "C:\\Desktop\\UofL\\2024 - Spring\\CIS 411\\Group Projects\\Second Half\\GroupAssignment3\\GroupAssignment3\\TestFile.xml";

    //        XmlDocument xmlDoc = new XmlDocument();
    //        XmlSerializer serializer = new XmlSerializer(typeof(User));
    //        using (MemoryStream ms = new MemoryStream())
    //        {
    //            serializer.Serialize(ms, student1);
    //            ms.Position = 0;
    //            xmlDoc.Load(ms);
    //            xmlDoc.Save(filename);
    //            ms.Close();
    //        }
    //    }
    //}
}

