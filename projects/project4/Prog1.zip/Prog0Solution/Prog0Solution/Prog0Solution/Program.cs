﻿//Austin Calhoun
//Student ID: 1850661
//Program 1

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0Solution
{
    class Program
    {
        static void Main(string[] args)
        {
            //create sample CPU for use in Computer Objects
            CPU cpu1 = new CPU("Intel", "i7-5930k", 3500, "2011-3", 140);
            CPU cpu2 = new CPU("AMD", "Ryzen 3700X", 3600, "AM4", 65);
            CPU cpu3 = new CPU("Intel", "i3-4150", 3500, "FCLGA1150", 54);

            //Sample GPU objects
            GPU gpu1 = new GPU(" AMD ", " 79000x ", 6000, 650);
            GPU gpu2 = new GPU(" NVIDIA ", " 4900 ", 7000, 950);
            GPU gpu3 = new GPU(" AMD ", " 79000xtx ", 6500, 750);

            //Sample Motherboard objects
            MotherBoard motherboard1 = new MotherBoard("ASUS", "B150", "2011 - 3", 95);
            MotherBoard motherboard2 = new MotherBoard("GIGABYTE", "B450", "AM4", 120);
            MotherBoard motherboard3 = new MotherBoard("ZOTAC", "B560", "FCLGA1150", 100);


            //create sample tower objects for test data
            Tower tower1 = new Tower(" HP ", cpu2, gpu1, motherboard1, 4, "Glass" );
            Tower tower2 = new Tower(" Acer ", cpu3, gpu2, motherboard3, 5, "Glass");
            Tower tower3 = new Tower(" Lenovo ", cpu1, gpu3 , motherboard2, 3, "Metal");
            Tower tower4 = new Tower(" Dell ", cpu1, gpu1, motherboard1, 4, "Glass");

            List<Desktop> computerList = new List<Desktop> {tower1,tower2,tower3,tower4};

            foreach (Desktop tower in computerList)
            {
                Console.WriteLine(tower);
                Console.WriteLine($"TDP for this Computer is {tower.CalcTDP()} Watts");
                //print a separator between each for visual clarity;
                Console.WriteLine();
                Console.WriteLine("------------------------------------");
                Console.WriteLine();
            }
        }
    }
}
