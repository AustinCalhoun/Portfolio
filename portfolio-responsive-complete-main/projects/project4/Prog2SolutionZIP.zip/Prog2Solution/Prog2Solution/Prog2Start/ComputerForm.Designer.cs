﻿namespace Prog3Start
{
    partial class computerViewForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.compListView = new System.Windows.Forms.ListView();
            this.manHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tdpHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.deviceHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.computerMenuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.insertToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.laptopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allInOneToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.towerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.detailsButton = new System.Windows.Forms.Button();
            this.computerErrorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.computerMenuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.computerErrorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // compListView
            // 
            this.compListView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.compListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.manHeader,
            this.tdpHeader,
            this.deviceHeader});
            this.compListView.HideSelection = false;
            this.compListView.Location = new System.Drawing.Point(45, 42);
            this.compListView.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.compListView.MultiSelect = false;
            this.compListView.Name = "compListView";
            this.compListView.Size = new System.Drawing.Size(392, 392);
            this.compListView.TabIndex = 0;
            this.compListView.UseCompatibleStateImageBehavior = false;
            this.compListView.View = System.Windows.Forms.View.Details;
            // 
            // manHeader
            // 
            this.manHeader.Text = "Manufacturer";
            this.manHeader.Width = 87;
            // 
            // tdpHeader
            // 
            this.tdpHeader.Text = "TDP";
            this.tdpHeader.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // deviceHeader
            // 
            this.deviceHeader.Text = "Device Type";
            this.deviceHeader.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.deviceHeader.Width = 87;
            // 
            // computerMenuStrip
            // 
            this.computerMenuStrip.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.computerMenuStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.computerMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.insertToolStripMenuItem});
            this.computerMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.computerMenuStrip.Name = "computerMenuStrip";
            this.computerMenuStrip.Size = new System.Drawing.Size(477, 35);
            this.computerMenuStrip.TabIndex = 1;
            this.computerMenuStrip.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem,
            this.exitToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.loadToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(54, 29);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // insertToolStripMenuItem
            // 
            this.insertToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.laptopToolStripMenuItem,
            this.allInOneToolStripMenuItem,
            this.towerToolStripMenuItem});
            this.insertToolStripMenuItem.Name = "insertToolStripMenuItem";
            this.insertToolStripMenuItem.Size = new System.Drawing.Size(72, 29);
            this.insertToolStripMenuItem.Text = "Insert";
            // 
            // laptopToolStripMenuItem
            // 
            this.laptopToolStripMenuItem.Name = "laptopToolStripMenuItem";
            this.laptopToolStripMenuItem.Size = new System.Drawing.Size(192, 34);
            this.laptopToolStripMenuItem.Text = "Laptop";
            this.laptopToolStripMenuItem.Click += new System.EventHandler(this.laptopToolStripMenuItem_Click);
            // 
            // allInOneToolStripMenuItem
            // 
            this.allInOneToolStripMenuItem.Name = "allInOneToolStripMenuItem";
            this.allInOneToolStripMenuItem.Size = new System.Drawing.Size(192, 34);
            this.allInOneToolStripMenuItem.Text = "All In One";
            this.allInOneToolStripMenuItem.Click += new System.EventHandler(this.allInOneToolStripMenuItem_Click);
            // 
            // towerToolStripMenuItem
            // 
            this.towerToolStripMenuItem.Name = "towerToolStripMenuItem";
            this.towerToolStripMenuItem.Size = new System.Drawing.Size(192, 34);
            this.towerToolStripMenuItem.Text = "Tower";
            this.towerToolStripMenuItem.Click += new System.EventHandler(this.towerToolStripMenuItem_Click);
            // 
            // detailsButton
            // 
            this.detailsButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.detailsButton.Location = new System.Drawing.Point(177, 440);
            this.detailsButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.detailsButton.Name = "detailsButton";
            this.detailsButton.Size = new System.Drawing.Size(112, 35);
            this.detailsButton.TabIndex = 2;
            this.detailsButton.Text = "Details";
            this.detailsButton.UseVisualStyleBackColor = true;
            this.detailsButton.Click += new System.EventHandler(this.detailsButton_Click);
            // 
            // computerErrorProvider
            // 
            this.computerErrorProvider.ContainerControl = this;
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // loadToolStripMenuItem
            // 
            this.loadToolStripMenuItem.Name = "loadToolStripMenuItem";
            this.loadToolStripMenuItem.Size = new System.Drawing.Size(270, 34);
            this.loadToolStripMenuItem.Text = "Load";
            this.loadToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
            // 
            // computerViewForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(477, 494);
            this.Controls.Add(this.detailsButton);
            this.Controls.Add(this.compListView);
            this.Controls.Add(this.computerMenuStrip);
            this.MainMenuStrip = this.computerMenuStrip;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "computerViewForm";
            this.Text = "User Computer View";
            this.computerMenuStrip.ResumeLayout(false);
            this.computerMenuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.computerErrorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView compListView;
        private System.Windows.Forms.ColumnHeader manHeader;
        private System.Windows.Forms.ColumnHeader tdpHeader;
        private System.Windows.Forms.ColumnHeader deviceHeader;
        private System.Windows.Forms.MenuStrip computerMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem insertToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem laptopToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allInOneToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem towerToolStripMenuItem;
        private System.Windows.Forms.Button detailsButton;
        private System.Windows.Forms.ErrorProvider computerErrorProvider;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToolStripMenuItem;
    }
}

