﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0Solution
{
    class Tower : Desktop
    {
        private string panelType;
        string Glass = "Glass";
        string Metal = "Metal";
        public Tower(string manufacturer, CPU cpu, GPU gpu, MotherBoard motherBoard, int fanCount, string panelType) //constructor
            : base(manufacturer, cpu, gpu, motherBoard, fanCount)
        {
            PanelType = panelType;
        }
        public string PanelType
        {
            get
            {
                return panelType;
            }
            set
            {
                if (value == Glass || value == Metal)
                {
                    panelType = value.Trim();
                }
                else
                {
                    throw new ArgumentOutOfRangeException();
                }

            }
        }

        public override double CalcTDP() //CPU.PowerDraw + GPU.PowerDraw + MotherBoard.PowerDraw
        {
            return CPU.PowerDraw + GPU.PowerDraw + MotherBoard.PowerDraw;
        }
        public override string ToString()
        {
            return $"Manufacturer: {Manufacturer} \nCPU Details: {CPU}\nGPU Details: {GPU}\nMotherBoard Details: {MotherBoard}\nFan Count: {FanCount}\nPanel Type: {PanelType}";
        }
    }
}
