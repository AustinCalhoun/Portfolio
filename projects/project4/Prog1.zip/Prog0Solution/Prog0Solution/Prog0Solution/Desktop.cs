﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Prog0Solution
{
    abstract class Desktop : Computer
    {
        private int fanCount;
        private GPU gpu;
        private MotherBoard motherBoard;
        public Desktop(string manufacturer, CPU cpu, GPU gpu, MotherBoard motherBoard, int fanCount)//constructor
            : base(manufacturer, cpu)
        {
            GPU = gpu;
            MotherBoard = motherBoard;
            FanCount = fanCount;
        }

        public GPU GPU//set class property
        {
            get
            {
                return gpu;
            }
            set
            {
                gpu = value;
            }
        }
        public MotherBoard MotherBoard//set class property
        {
            get
            {
                return motherBoard;
            }
            set
            {
                motherBoard = value;
            }
        }
        public int FanCount//set property
        {
            get
            {
                return fanCount;
            }
            set
            {
                if (value >= 0 && value <= 10)
                {
                    fanCount = value;
                }
                else
                {
                    throw new ArgumentOutOfRangeException();

                }
            }
        }
        public override string ToString()
        {
            return $"Manufacturer: {Manufacturer} \nCPU Details: {CPU}\nGPU Details: {GPU}\nMotherBoard Details: {MotherBoard}\nFan Count: {FanCount}";
        }

    }
}
