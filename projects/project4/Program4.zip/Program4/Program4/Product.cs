﻿/*
Grading ID: F2207
Program: 4
Due Date: 12/02/2022
Course Section: CIS-199-50-4228
This code executes program 4
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    public class Product
    {
        // fields
        private string supplierName;
        private string productName;
        private int productID;
        private string productType;
        private double productPrice;
        private int aisleLocation;
        private bool inStockValue;

        //6-parameter constructor used to instatiate objects
        public Product(string supplierName, string productName, int productID, string productType, double productPrice, int aisleLocation)
        {
            SupplierName = supplierName;
            ProductName = productName;
            ProductID = productID;
            ProductType = productType;
            ProductPrice = productPrice;
            AisleLocation = aisleLocation;

        }
        //get and set is used for the following objects
        public string SupplierName 
        { 
            get 
            { 
                return supplierName; 
            } 
            set 
            { 
                productName = value; 
            } 
        }
        public string ProductName 
        {
            get 
            { 
                return productName; 
            } 
            set 
            { 
                productName = value; 
            } 
        }

        public int ProductID
        {
            get 
            { 
                return productID; 
            }
            set
            {
                // Setting range for productID
                if (value >= 100000 && value <= 999999)
                {
                    productID = 0;
                }
            }
        }

        public string ProductType 
        { 
            get 
            { 
                return productType; 
            } 
            set 
            { productType = value; 
            } 
        }

        public double ProductPrice
        {
            get { return productPrice; }
            set
            {
                // Setting range for ProductPrice if no entry prive = 0
                if (value > 0)
                {
                    productPrice = value;
                }
                else
                {
                    productPrice = 0;
                }
            }
        }

        public int AisleLocation
        {
            get { return aisleLocation; }
            set
            {
                //Setting range for aisleLocation
                if (value >= 1 && value <= 20)
                {
                    aisleLocation = value;
                }
                else
                {
                    aisleLocation = 0;
                }

            }
        }

        public void InStock()
        {
            inStockValue = !inStockValue;
        }

        public void OutStock()
        {
            inStockValue = !inStockValue;
        }

        public bool OutofStock()
        {
            return inStockValue;
        }

        public override string ToString()
        {
            return //Strings that display data from program class
                $"Supplier: {SupplierName} " + Environment.NewLine
                + $"Product: {productName}" + Environment.NewLine
                + $"ID: {productID}" + Environment.NewLine
                + $"Type: {ProductType}" + Environment.NewLine
                + $"Price: {ProductPrice.ToString("C")}" + Environment.NewLine
                + $"Aisle: {AisleLocation}" + Environment.NewLine
                + $"In Stock?: {OutofStock()}" + Environment.NewLine;
        }
    }
}
